
# # # # # # # # # # # # # # #

UN LUGAR BAJO EL MAR (DROWNING, DROWNING)
*version 1.0

# # # # # # # # # # # # # # #
por NomnomNami

contacto: nomnomnamidev@gmail.com
página del juego: https://nomnomnami.itch.io/drowning-drowning
hecho con RPGMaker VX Ace

por favor, no redistribuyas este juego sin permiso.

# # # # # # # # # # # # # # #

- !! SECCIÓN DE AYUDA !! -
Para arrancar el juego, descomprime el archivo y haz doble clic en el archivo "game.exe" situado en la carpeta del juego.

Si aparece un error al abrir el juego, prueba a descargar el RTP desde el siguiente enlace:
https://www.rpgmakerweb.com/download/additional/run-time-packages

- Controles -
flechas de dirección = moverse (mantén pulsado shift para correr)
enter, barra espaciadora, z = confirmar/seleccionar
esc, 0, x = cancelar
F5 = pantalla completa
alt+enter = alternar pantalla completa (estirado)

# # # # # # # # # # # # # # #

~ CRÉDITOS ~

- Historia+Arte -
  NomnomNami

- Música -
  Kamilla's Rainbow

- Testeo+Feedback -
  chunderfins
  cloverfirefly
  cosmicApproach
  DCS
  Fah Braccini
  LydianChord
  Mabs
  npckc
  Pivi
  PlushMayhem

- Traducción -
  Gabriel Fiallegas Medina
  (Basajaun Games)

- Mecenas -
  areforever
  August Parmin
  Grievance
  Ing
  IngYa
  Luna
  Malkavio
  NthPortal
  Radsjet
  Sam Caesar
  Tasi Turney

# # # # # # # # # # # # # # #

~ SCRIPTS UTILIZADOS ~
Non-Combat Menu - mjshi
https://pastebin.com/wvbrcAS9

Text Cache - Mithran
https://forums.rpgmakerweb.com/index.php?threads/text-cache.1001/

Fullscreen++ - Zeus81
https://forums.rpgmakerweb.com/index.php?threads/fullscreen.14081/

# # # # # # # # # # # # # # #

¡si te ha gustado el juego y quieres apoyarme para que pueda hacer más,
puedes visitar mi patreon!
https://www.patreon.com/nomnomnami

puedes encontrar un enlace a la banda sonora en la página de itch.io
¡si te ha gustado la música, apoya también a Kamilla's Rainbow, por favor!

¡gracias por descargártelo!

<3 nami
