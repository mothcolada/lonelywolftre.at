
# # # # # # # # # # # # # # #

DROWNING, DROWNING
沉溺深海
*版本 1.0

# # # # # # # # # # # # # # #
NomnomNami出品

联系方式: nomnomnamidev@gmail.com
游戏页面: https://nomnomnami.itch.io/drowning-drowning
使用RPGMaker VX Ace制作

未经允许，请不要重新发布此游戏.

# # # # # # # # # # # # # # #

- !! 帮助 !! -
要启动游戏，请解压缩文件并双击位于游戏文件夹中的“game.exe”.

如果游戏在启动时崩溃，请尝试从这里下载RTP:
https://www.rpgmakerweb.com/download/additional/run-time-packages

- 控制 -
方向键 = 移动 (按住shift跑步)
enter, 空格, z = 确认/选择
esc, 0, x = 取消
F5 = 全屏
alt+enter = 适应全屏 (拉伸)

# # # # # # # # # # # # # # #

~ 除此之外 ~

- 故事+美术 -
  NomnomNami

- 音乐 -
  Kamilla's Rainbow

- 测试+反馈 -
  chunderfins
  cloverfirefly
  cosmicApproach
  DCS
  Fah Braccini
  LydianChord
  Mabs
  npckc
  Pivi
  PlushMayhem

- 由赞助者提供支持 -
  areforever
  August Parmin
  Grievance
  Ing
  IngYa
  Luna
  Malkavio
  NthPortal
  Radsjet
  Sam Caesar
  Tasi Turney

# # # # # # # # # # # # # # #

~ 使用的脚本 ~
Non-Combat Menu（非战斗菜单） - mjshi
https://pastebin.com/wvbrcAS9

Text Cache（文本缓存） - Mithran
https://forums.rpgmakerweb.com/index.php?threads/text-cache.1001/

Fullscreen++（全屏） - Zeus81
https://forums.rpgmakerweb.com/index.php?threads/fullscreen.14081/

# # # # # # # # # # # # # # #

如果你喜欢这个游戏，并想支持我进行更多创作的话,
你可以去我的patreon!
https://www.patreon.com/nomnomnami

如果你喜欢游戏配乐的话可以去itch.io的页面获取链接, 
也请支持Kamilla's Rainbow!

感谢你的下载!

<3（啵啵） nami

//——————————//
译者附
中文翻译若有任何错误请及时与polaris联系，邮箱：2914997386@qq.com 
欢迎小伙伴的纠错，指正和建议，谢谢！
Drowning Drowning 简体中文版由Polaris翻译，Mimosa校对润色，若有任何问题也可以联系Mimosa，邮箱：826736513@qq.com

使用的字体为LanaPixel，若字体显示不对，请先安装LanaPixel（安装包已附于fonts文件夹，无法安装请前往官网下载）

 ミ( ‘ ▽ ` )彡 
    c         つ 呜啪！ 
        \     |  
        u - uフ°  