
# # # # # # # # # # # # # # #

DROWNING, DROWNING
*version 1.1

# # # # # # # # # # # # # # #
par NomnomNami

Contact : nomnomnamidev@gmail.com
Page du jeu : https://nomnomnami.itch.io/drowning-drowning
Réalisé avec RPGMaker VX Ace

Merci de ne pas redistribuer ce jeu sans ma permission.

# # # # # # # # # # # # # # #

- !! AIDE !! -
Pour lancer le jeu, décompressez le fichier et double-cliquez sur "game.exe" dans le fichier du jeu.

Si le jeu plante au démarrage, essayez de télécharger le RTP à cette adresse :
https://www.rpgmakerweb.com/download/additional/run-time-packages

- Contrôles -
Flèches directionnelles = se déplacer (maintenez la touche Maj pour courir)
Entrée, espace, z = confirmer/sélectionner
Échap, 0, x = annuler
F5 = plein écran
Alt + entrée = autre mode plein écran (étiré)

# # # # # # # # # # # # # # #

~ CRÉDITS ~

- Histoire + graphismes -
  NomnomNami

- Musique -
  Kamilla's Rainbow

- Test + commentaires -
  chunderfins
  cloverfirefly
  cosmicApproach
  DCS
  Fah Braccini
  LydianChord
  Mabs
  npckc
  Pivi
  PlushMayhem

- Soutenu sur Patreon par -
  areforever
  August Parmin
  Grievance
  Ing
  IngYa
  Luna
  Malkavio
  NthPortal
  Radsjet
  Sam Caesar
  Tasi Turney

# # # # # # # # # # # # # # #

~ SCRIPTS EMPLOYÉ ~
Non-Combat Menu - mjshi
https://pastebin.com/wvbrcAS9

Text Cache - Mithran
https://forums.rpgmakerweb.com/index.php?threads/text-cache.1001/

Fullscreen++ - Zeus81
https://forums.rpgmakerweb.com/index.php?threads/fullscreen.14081/

# # # # # # # # # # # # # # #

Si vous avez aimé ce jeu et voulez me soutenir, vous pouvez passer sur ma page Patreon !
https://www.patreon.com/nomnomnami

Sur la page itch.io, vous pourrez trouver un lien pour l'OST du jeu.
Si les musiques du jeu vous ont plu, soutenez Kamilla's Rainbow aussi !!

Merci pour votre téléchargement !

<3 nami