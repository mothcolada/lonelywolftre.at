
# # # # # # # # # # # # # # #

DROWNING, DROWNING
*version 1.0

# # # # # # # # # # # # # # #
by NomnomNami

contact: nomnomnamidev@gmail.com
game page: https://nomnomnami.itch.io/drowning-drowning
made with RPGMaker VX Ace

please do not redistribute this game without permission.

# # # # # # # # # # # # # # #

- !! HELP !! -
To launch the game, unzip the file and double click "game.exe" located in the game folder.

If the game crashes upon launch, please try downloading the RTP from here:
https://www.rpgmakerweb.com/download/additional/run-time-packages

- Controls -
arrow keys = move (hold shift to run)
enter, space, z = confirm/select
esc, 0, x = cancel
F5 = fullscreen
alt+enter = alternate fullscreen (stretched)

# # # # # # # # # # # # # # #

~ CREDITS ~

- Story+Art -
  NomnomNami

- Music -
  Kamilla's Rainbow

- Testing+Feedback -
  chunderfins
  cloverfirefly
  cosmicApproach
  DCS
  Fah Braccini
  LydianChord
  Mabs
  npckc
  Pivi
  PlushMayhem

- Supported by Patrons -
  areforever
  August Parmin
  Grievance
  Ing
  IngYa
  Luna
  Malkavio
  NthPortal
  Radsjet
  Sam Caesar
  Tasi Turney

# # # # # # # # # # # # # # #

~ SCRIPTS USED ~
Non-Combat Menu - mjshi
https://pastebin.com/wvbrcAS9

Text Cache - Mithran
https://forums.rpgmakerweb.com/index.php?threads/text-cache.1001/

Fullscreen++ - Zeus81
https://forums.rpgmakerweb.com/index.php?threads/fullscreen.14081/

# # # # # # # # # # # # # # #

if you enjoyed the game and want to support me making more like it,
you can head on over to my patreon!
https://www.patreon.com/nomnomnami

a link to the game's soundtrack can be found on the itch.io page
if you liked the music, please support Kamilla's Rainbow as well!

thank you for downloading!

<3 nami
